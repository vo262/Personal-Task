﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Task_manager1
{
    public partial class SearchByDateForm : Form
    {
        private const string tasksFilePath = "tasks.txt";
        public SearchByDateForm()
        {
            InitializeComponent();
        }

        private void listBoxSearch_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker_ValueChanged(object sender, EventArgs e)
        {

        }

        private void Searchbydate_Click(object sender, EventArgs e)
        {
            DateTime searchDate = dateTimePicker.Value;

            
            SearchTasksByDate(searchDate);
        }

        private void SearchTasksByDate(DateTime searchDate)
        {
            try
            {
                
                string[] tasks = File.ReadAllLines(tasksFilePath);

                
                var filteredTasks = tasks.Where(task =>
                {
                    string[] taskParts = task.Split(',');
                    if (taskParts.Length >= 3 && DateTime.TryParse(taskParts[2], out DateTime taskDate))
                    {
                        return taskDate.Date == searchDate.Date;
                    }
                    return false;
                });

               
                listBoxSearch.Items.Clear();
                listBoxSearch.Items.AddRange(filteredTasks.ToArray());
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error searching tasks: {ex.Message}");
            }
        }
    }
}
