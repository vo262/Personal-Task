﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Task_manager1
{
    public partial class UpdateTask : Form
    {
        private const string tasksFilePath = "tasks.txt";
        public UpdateTask()
        {
            InitializeComponent();
        }

        private void UpdateTask_Load(object sender, EventArgs e)
        {
            LoadTasks();
        }

        private void LoadTasks()
        {
            
            try
            {
                string[] tasks = File.ReadAllLines(tasksFilePath);
                listBoxTask.Items.AddRange(tasks);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading tasks: {ex.Message}");
            }
        }

        private void buttonUpdate_Click(object sender, EventArgs e)
        {
            if (listBoxTask.SelectedIndex != -1)
            {
               
                string selectedTask = listBoxTask.SelectedItem.ToString();

                // Show a form to input updated task details
                TaskDetailsForm taskDetailsForm = new TaskDetailsForm(selectedTask);
                if (taskDetailsForm.ShowDialog() == DialogResult.OK)
                {
                 
                    try
                    {
                        int selectedIndex = listBoxTask.SelectedIndex;
                        listBoxTask.Items[selectedIndex] = taskDetailsForm.UpdatedTaskDetails;
                        File.WriteAllLines(tasksFilePath, listBoxTask.Items.Cast<string>());
                        MessageBox.Show("Task updated successfully.");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error updating task: {ex.Message}");
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a task to update.");
            }
        }
    }
}
