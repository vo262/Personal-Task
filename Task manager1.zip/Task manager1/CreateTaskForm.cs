﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


namespace Task_manager1
{
    public partial class CreateTaskForm : Form
    {
        private const string tasksFilePath = "tasks.txt";
        public CreateTaskForm()
        {
            InitializeComponent();
        }

        private void btCreateTask_Click(object sender, EventArgs e)
        {
            string description = textDescription.Text;
            string priority = comboPriority.Text;
            DateTime dateTime = dateTimePicker.Value;

            string taskDetails = $"{description},{priority},{dateTime}";

            try
            {
                File.AppendAllText(tasksFilePath, taskDetails + Environment.NewLine);
                MessageBox.Show("Task created successfully.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error creating task: {ex.Message}");
            }

            this.Close();
        }
    }
}
