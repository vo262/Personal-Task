﻿namespace Task_manager1
{
    partial class DeleteTaskForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ListBoxTask = new System.Windows.Forms.ListBox();
            this.Delete = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // ListBoxTask
            // 
            this.ListBoxTask.FormattingEnabled = true;
            this.ListBoxTask.ItemHeight = 16;
            this.ListBoxTask.Location = new System.Drawing.Point(12, 30);
            this.ListBoxTask.Name = "ListBoxTask";
            this.ListBoxTask.Size = new System.Drawing.Size(323, 388);
            this.ListBoxTask.TabIndex = 0;
            this.ListBoxTask.SelectedIndexChanged += new System.EventHandler(this.ListBoxTask_SelectedIndexChanged);
            // 
            // Delete
            // 
            this.Delete.Location = new System.Drawing.Point(438, 198);
            this.Delete.Name = "Delete";
            this.Delete.Size = new System.Drawing.Size(142, 42);
            this.Delete.TabIndex = 1;
            this.Delete.Text = "Delete button";
            this.Delete.UseVisualStyleBackColor = true;
            this.Delete.Click += new System.EventHandler(this.Delete_Click);
            // 
            // DeleteTaskForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Delete);
            this.Controls.Add(this.ListBoxTask);
            this.Name = "DeleteTaskForm";
            this.Text = "DeleteTaskForm";
            this.Load += new System.EventHandler(this.DeleteTaskForm_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox ListBoxTask;
        private System.Windows.Forms.Button Delete;
    }
}