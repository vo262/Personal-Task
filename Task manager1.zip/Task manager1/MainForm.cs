﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Task_manager1
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void btcreateTask_Click(object sender, EventArgs e)
        {
            CreateTaskForm createTaskForm = new CreateTaskForm();
            createTaskForm.ShowDialog();
        }

        private void btupdateTask_Click(object sender, EventArgs e)
        {
            UpdateTask updateTaskForm = new UpdateTask();
            updateTaskForm.ShowDialog();
        }

        private void btdeleteTask_Click(object sender, EventArgs e)
        {
            DeleteTaskForm deleteTaskForm = new DeleteTaskForm();
            deleteTaskForm.ShowDialog();
        }

        private void btviewTask_Click(object sender, EventArgs e)
        {
            ViewTaskForm viewTasksForm = new ViewTaskForm();
            viewTasksForm.ShowDialog();
        }

        private void btsearchTask_Click(object sender, EventArgs e)
        {
            SearchByDateForm searchByDateForm = new SearchByDateForm();
            searchByDateForm.ShowDialog();
        }
    }
}
