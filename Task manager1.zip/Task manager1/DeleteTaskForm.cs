﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Task_manager1
{
    public partial class DeleteTaskForm : Form
    {
        private const string tasksFilePath = "tasks.txt";
        public DeleteTaskForm()
        {
            InitializeComponent();
        }

        private void ListBoxTask_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Delete_Click(object sender, EventArgs e)
        {
            
            if (ListBoxTask.SelectedIndex != -1)
            {
                
                string selectedTask = ListBoxTask.SelectedItem.ToString();

                try
                {
                    ListBoxTask.Items.Remove(selectedTask);
                    File.WriteAllLines(tasksFilePath, ListBoxTask.Items.Cast<string>());
                    MessageBox.Show("Task deleted successfully.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error deleting task: {ex.Message}");
                }
            }
            else
            {
                MessageBox.Show("Please select a task to delete.");
            }
        }

        private void DeleteTaskForm_Load(object sender, EventArgs e)
        {
            LoadTasks();
        }

        private void LoadTasks()
        {
            
            try
            {
                string[] tasks = File.ReadAllLines(tasksFilePath);
                ListBoxTask.Items.AddRange(tasks);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading tasks: {ex.Message}");
            }
        }
    }
}
