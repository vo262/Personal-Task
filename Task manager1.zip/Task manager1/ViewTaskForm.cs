﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Task_manager1
{
    public partial class ViewTaskForm : Form
    {
        private const string tasksFilePath = "tasks.txt";
        public ViewTaskForm()
        {
            InitializeComponent();
        }

        private void ViewTaskForm_Load(object sender, EventArgs e)
        {
            LoadTasks();
        }
        private void LoadTasks()
        {
            
            try
            {
                string[] tasks = File.ReadAllLines(tasksFilePath);
                listBoxTask.Items.AddRange(tasks);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading tasks: {ex.Message}");
            }
        }
    }
}
