﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Task_manager1
{
    public partial class loginform : Form
    {
        private const string loginFilePath = "login_info.txt";
        private const string defaultPin = "1234";
        private const string defaultUsername = "prg455";
        private int loginAttempts = 0;
        
        public loginform()
        {
            InitializeComponent();
        }

        private void btlogin_Click(object sender, EventArgs e)
        {
            string enteredPin = textPin.Text;

            if (VerifyLogin(defaultUsername, enteredPin))
            {

                DialogResult = DialogResult.OK;


                MainForm mainForm = new MainForm();
                mainForm.Show();
                this.Hide();
            }
            else
            {
                loginAttempts++;

                if (loginAttempts >= 3)
                {
                    MessageBox.Show("Too many incorrect attempts. Exiting application.");
                    Application.Exit();
                }
                else
                {
                    MessageBox.Show($"Incorrect PIN. {3 - loginAttempts} attempts remaining.");
                    textPin.Clear();
                }
            }
        }
        private bool VerifyLogin(string username, string pin)
        {
            string[] loginInfo = File.ReadAllLines(loginFilePath);

            foreach (string line in loginInfo)
            {
                string[] parts = line.Split(',');

                if (parts.Length == 2 && parts[0].Trim() == username && parts[1].Trim() == pin)
                {
                    return true;
                }
            }

            return false;
        }
        private void buttonChangePin_Click(object sender, EventArgs e)
        {
            if (textUsername.Text.Trim() == defaultUsername)
            {
                File.WriteAllText(loginFilePath, $"{defaultUsername},{textnewpin.Text}");
                MessageBox.Show("PIN changed successfully.");
                textnewpin.Clear();
            }
            else
            {
                MessageBox.Show("You don't have permission to change the PIN.");
            }
        }
       
    }
}

       