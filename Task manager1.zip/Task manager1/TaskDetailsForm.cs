﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Task_manager1
{
    public partial class TaskDetailsForm : Form
    {
        public string UpdatedTaskDetails { get; private set; }
        public TaskDetailsForm(string initialTaskDetails)
        {
            InitializeComponent();

            string[] parts = initialTaskDetails.Split(',');
            if (parts.Length >= 3)
            {
                textdescription.Text = parts[0];
                textpriority.Text = parts[1];
                dateTimePicker.Value = DateTime.Parse(parts[2]);
            }


        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            string updatedDescription = textdescription.Text;
            string updatedPriority = textpriority.Text;
            DateTime updatedDateAndTime = dateTimePicker.Value;


            UpdatedTaskDetails = $"{updatedDescription},{updatedPriority},{updatedDateAndTime}";


            DialogResult = DialogResult.OK;
            Close();
        }
    }
}
